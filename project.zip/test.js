
let calculator = {
    add: (a ,b) => a + b,
    gob: (a ,b) => a * b,
    sdfdfdfdfdfdfdf: (a, b) => a / b,
}

module.exports = calculator;

exports.add = add; // 모듈 외부로 공개할 이름 .add / 모듈 내부에서의 이름.